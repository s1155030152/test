module.exports = {
	// TODO: change this yourself
	"dbURI": "mysql://shopXX-admin:mypass@localhost/shopXX"
};